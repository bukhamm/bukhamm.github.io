Red Dead Redemption 2 Naked Sadie by QwardNaffle

================
==DESCRIPTION==
===============
Replaces all of Sadie's outfits with a completely nude variant.

================
==INSTALLATION==
================
1. Make sure you have the Lenny's Mod Loader installed. 
Link: https://nudepatch.net/red-dead-redemption-2-lennys-mod-loader/
2. Extract "lml" folder from this compressed package into your RDR2 game file location.
3. Done! Enjoy!
================

For more information visit http://nudepatch.net/