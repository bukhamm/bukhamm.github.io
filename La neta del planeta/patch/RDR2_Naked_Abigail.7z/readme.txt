Red Dead Redemption 2 Naked Abigail by QwardNaffle

================
==DESCRIPTION==
===============
Replaces all of Abigail Marston's costumes with a completely nude version.

Included the "metapeds.ymt" file that also compatible with Nude Sadie & Nude Mary Linton. 
Links: https://nudepatch.net/red-dead-redemption-2-naked-mary/
       https://nudepatch.net/red-dead-redemption-2-naked-sadie/
It will cause problems with their costumes if you don't install their respective nude mods. 

Abigail's hair was a bit wonky by default, so it was added a good looking stand in that works fine. 


Requires Lenny's Mod Loader:
https://nudepatch.net/red-dead-redemption-2-lennys-mod-loader/

================
==INSTALLATION==
================
1. Make sure you have the Lenny's Mod Loader installed. 
Link: https://nudepatch.net/red-dead-redemption-2-lennys-mod-loader/
2. Extract the "lml" folder from this compressed package into your RDR2 game file location.
3. Done! Enjoy!

================

For more information visit http://nudepatch.net/