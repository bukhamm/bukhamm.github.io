Red Dead Redemption 2 Naked Mary-Beth by QwardNaffle

================
==DESCRIPTION==
===============
Replaces all of Mary-Beth Gaskill's outfits with completely nude variants.

This "metaped.ymt" file is also compatible with RDR 2 other nude mods like:
Naked Sadie https://nudepatch.net/red-dead-redemption-2-naked-sadie/
Naked Mary Linton https://nudepatch.net/red-dead-redemption-2-naked-mary/
Naked Abigail https://nudepatch.net/red-dead-redemption-2-naked-abigail/

It will make any gang females have outfit issues if you don't have their respective nude mods.


Requires Lenny's Mod Loader:
https://nudepatch.net/red-dead-redemption-2-lennys-mod-loader/

================
==INSTALLATION==
================
1. Make sure you have the Lenny's Mod Loader installed. 
Link: https://nudepatch.net/red-dead-redemption-2-lennys-mod-loader/
2. Extract the "lml" folder from this compressed package into your RDR2 game file location.
3. Done! Enjoy!

================

For more information visit http://nudepatch.net/