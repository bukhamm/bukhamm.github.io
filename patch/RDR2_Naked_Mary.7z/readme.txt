Red Dead Redemption 2 Naked Mary by QwardNaffle

================
==DESCRIPTION==
===============
Replaces Mary Linton's outfits with a completely nude version.

This metaped.ymt is also compatible with Nude Sadie. Link: https://nudepatch.net/red-dead-redemption-2-naked-sadie/
It will make her outfits have issues if you don't have her nude.


Requires Lenny's Mod Loader:
https://nudepatch.net/red-dead-redemption-2-lennys-mod-loader/

================
==INSTALLATION==
================
1. Make sure you have the Lenny's Mod Loader installed. 
Link: https://nudepatch.net/red-dead-redemption-2-lennys-mod-loader/
2. Extract "lml" folder from this compressed package into your RDR2 game file location.
3. Done! Enjoy!

================

For more information visit http://nudepatch.net/